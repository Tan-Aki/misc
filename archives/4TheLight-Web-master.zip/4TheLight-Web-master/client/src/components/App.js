import React from 'react';

import MainLayout from './layout/main';
import Pages from './pages';

import './App.css';

function App() {
  return (
    <div className="App">
      <MainLayout>
        <Pages />
      </MainLayout>
    </div>
  );
}

export default App;
