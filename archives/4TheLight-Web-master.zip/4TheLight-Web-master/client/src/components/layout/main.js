export default (props) => {
  return ["[MAIN]", props.children];
}