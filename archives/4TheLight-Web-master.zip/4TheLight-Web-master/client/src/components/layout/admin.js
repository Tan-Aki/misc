export default (props) => {
  return ["[ADMIN]", props.children];
}