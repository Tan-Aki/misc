export default (props = {code: 404}) => {
  return `Error ${props.code}`
}