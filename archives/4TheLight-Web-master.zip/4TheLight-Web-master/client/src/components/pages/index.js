// Router
import React from 'react';
import { Route, Switch } from "react-router-dom";

import HomePage from './home';
import ErrorPage from './error';
import BlogPage from './blog';
import AdminPage from './admin';

// import axios from 'axios';

export default () => {
  return (
    <Switch>
      <Route path="/" exact component={HomePage} />
      <Route path="/blog" component={BlogPage} />
      <Route path="/admin" component={AdminPage} />

      <Route render={() => <ErrorPage code={404} />} />
    </Switch>
  );
}