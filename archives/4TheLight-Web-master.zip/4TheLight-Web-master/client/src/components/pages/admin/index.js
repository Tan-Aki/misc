export default (props) => {
  return `ADMIN`
}