import { Blog } from '../../../lib/sdk';
import { useState, useEffect } from 'react';

export default () => {
  const [ blogState, setPosts ] = useState({isLoading: true, posts: []});

  // Move this in centralized store (like Redux)
  useEffect(() => {
    // Create an async function and call it directly (use effect need a function, not async)
    (async () => setPosts({
      isLoading: false,
      posts: await Blog.getAll()
    }))();

  }, []);

  // console.log(await Blog.getAll());
  return `Blog: ${blogState.posts.length} posts`;
}