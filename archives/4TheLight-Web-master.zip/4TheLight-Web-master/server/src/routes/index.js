const router = require("express").Router();
const blogposts = require('./blog');

router.use('/blog', blogposts); // Go throw blog

module.exports = router;