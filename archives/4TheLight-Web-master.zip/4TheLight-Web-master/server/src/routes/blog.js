const router = require("express").Router();

const { mustBe } = require('../lib/auth');
const BlogPosts = require('../database/blogposts');
const blog = require('../controllers/blog.js');


router.get('/:id', blog.findOne);
router.get('/', blog.findAll);
router.post('/', /* mustBe('admin'), */ blog.create);
router.put('/:id', /* mustBe('admin'), */ blog.update);
router.delete('/:id', /* mustBe('admin'), */ blog.delete);

module.exports = router;