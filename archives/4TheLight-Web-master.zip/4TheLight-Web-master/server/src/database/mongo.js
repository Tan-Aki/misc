// const { MongoMemoryServer } = require('mongodb-memory-server');
const { ObjectID, MongoClient } = require('mongodb');

// const config = require('../config/database.config.js');

let database = null;

async function startDatabase() {
  // const mongo = new MongoMemoryServer();
  // const mongoDBURL = await mongo.getConnectionString();
  const connection = await MongoClient
    .connect(process.env.MONGO_URL, {useNewUrlParser: true})
    // .catch(err => console.warn("MongoClient catch: ", err));
  database = connection.db();
}

async function getDatabase() {
  if (!database) await startDatabase();
  return database;
}

function getCRUD(collectionName) {

  async function insert(doc) {
    const db = await getDatabase();
    const {insertedId} = await db.collection(collectionName).insertOne(doc)
      // .then(result => console.log(`Successfully inserted item with _id: ${result.insertedId}`))
      // .catch(err => console.error(`Failed to insert item: ${err}`))
      // // .catch(err => console.warn("MongoClient catch: ", err));

    return insertedId;
  }
  async function get(id=null) {
    const db = await getDatabase();
    if (id) {
      console.log(`@TODO: Return one collection=${collectionName} id=${id}`);
    }
    return await db.collection(collectionName).find({}).toArray();
  }

  async function update(id, doc) {
    const db = await getDatabase();
    delete doc._id;
    await db.collection(collectionName).update(
      { _id: new ObjectID(id), },
      { $set: { ...doc }, },
    );
  }
  async function remove(id) {
    const db = await getDatabase();
    await db.collection(collectionName).deleteOne({
      _id: new ObjectID(id),
    });
  }

  return { insert, get, update, remove }
}

module.exports = {
  getDatabase,
  startDatabase,
  getCRUD
};
