const { getCRUD } = require('./mongo');

// use default CRUD (no need to udpate)
module.exports = getCRUD('blogposts');
