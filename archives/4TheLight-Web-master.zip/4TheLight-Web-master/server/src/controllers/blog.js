const BlogPosts = require('../database/blogposts');

// Create and Save a new BlogPost
exports.create = async (req, res) => {
  // console.log("Create", req.body);
  res.send(await BlogPosts.insert(req.body));
};
// Retrieve and return all BlogPost.
exports.findAll = async (req, res) => {
  res.send(await BlogPosts.get());
};
// Find a single BlogPost
exports.findOne = async (req, res) => {
  res.send(await BlogPosts.get(req.params.id));
};
// Update a BlogPost
exports.update = async (req, res) => {
  res.send(await BlogPosts.get(req.params.id, req.body.blogpost));
};
// Delete a BlogPost
exports.delete = async (req, res) => {
  res.send(await BlogPosts.remove(req.params.id));
};