const express = require('express');
require('dotenv').config(); // Setup .env

const bodyParser = require('body-parser');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');

const { startDatabase } = require('./database/mongo');
const router = require('./routes');

const PORT = process.env.PORT || 7000;
const app = express();

app.use(helmet());
app.use(bodyParser.urlencoded());
app.use(bodyParser.json());
app.use(cors());
app.use(morgan('combined'));

app.use(router);

// Start the server
startDatabase().then(async () => {
  app.listen(PORT, async () => {
    console.log(`listening on port ${PORT}`);
  });
}).catch(async (e) => {
  console.warn(`Start DB error`, e);
});
