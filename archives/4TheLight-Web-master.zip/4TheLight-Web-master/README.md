# 4TheLight-Web

4TheLight WebSite, Blog, Wiki, ..


## Client

Install an run React server on port 7001 

```
cd client 
npm i
npm start
```

## Server

Require mongo running on port 27017. Start deamon:

```
mongod
```

Install an run NodeJS server on port 7000 

```
cd server 
npm i
npm start
```

##### Endpoints

- **GET** `/blog` - Get List of blog posts
- **GET** `/blog/:id` - Get Uniq blog posts
- **POST** `/blog` - Create new blog posts 
- **PUT** `/blog/:id` - Update blog posts 
- **DELETE** `/blog/:id` - Delete blog posts 
