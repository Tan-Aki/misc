System.register(['./non-existent.js'], function (_export, _context) {
  "use strict";

  return {
    setters: [function (_nonExistentJs) {}],
    execute: function () {}
  };
});