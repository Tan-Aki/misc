System.register([], function (_export, _context) {
  "use strict";

  var asdf;
  return {
    setters: [],
    execute: function () {
      _export('asdf', asdf = 'asdf');

      _export('asdf', asdf);
    }
  };
});