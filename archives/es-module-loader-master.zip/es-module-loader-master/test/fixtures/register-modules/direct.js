System.register(['./es6-dep.js'], function (_export, _context) {
  "use strict";

  var p;
  return {
    setters: [function (_es6DepJs) {
      p = _es6DepJs.p;
    }],
    execute: function () {}
  };
});