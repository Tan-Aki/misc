System.register([], function (_export, _context) {
  "use strict";

  var p;
  return {
    setters: [],
    execute: function () {
      _export("p", p = 4);

      _export("p", p);
    }
  };
});