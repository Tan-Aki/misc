System.register([], function (_export, _context) {
  "use strict";

  var b;
  return {
    setters: [],
    execute: function () {
      _export('b', b = 'b');

      _export('b', b);
    }
  };
});