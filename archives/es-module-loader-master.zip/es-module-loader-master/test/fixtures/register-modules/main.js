System.register(["./deperror.js"], function (_export, _context) {
  "use strict";

  return {
    setters: [function (_deperrorJs) {}],
    execute: function () {}
  };
});