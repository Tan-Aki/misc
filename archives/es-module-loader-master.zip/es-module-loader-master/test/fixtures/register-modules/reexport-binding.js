System.register(['./rebinding.js'], function (_export, _context) {
  "use strict";

  var p;
  return {
    setters: [function (_rebindingJs) {
      p = _rebindingJs.p;
    }],
    execute: function () {}
  };
});