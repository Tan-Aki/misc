System.register([], function (_export, _context) {
  "use strict";

  _export('default', function () {
    return 'test';
  });

  return {
    setters: [],
    execute: function () {}
  };
});