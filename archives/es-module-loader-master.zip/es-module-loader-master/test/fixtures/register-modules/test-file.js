System.register([], function (_export, _context) {
  "use strict";

  var s;
  function q() {}

  _export("default", q);

  return {
    setters: [],
    execute: function () {
      _export("s", s = 4);

      _export("s", s);
    }
  };
});