System.register(['./_d.js'], function (_export, _context) {
  "use strict";

  var c;
  return {
    setters: [function (_dJs) {
      var _exportObj = {};
      _exportObj.d = _dJs.d;

      _export(_exportObj);
    }],
    execute: function () {
      _export('c', c = 'c');

      _export('c', c);
    }
  };
});