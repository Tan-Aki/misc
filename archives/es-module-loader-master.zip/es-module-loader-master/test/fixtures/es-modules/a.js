export { b } from './b.js';
export var a = 'a';
