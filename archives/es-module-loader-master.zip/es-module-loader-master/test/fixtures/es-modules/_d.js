export var d = 'd';
